str=input("enter the string to find the sub strings:")

#we use two loops and we are using slicing operation
list=[]
for i in range(len(str)):
    for j in range(i+1,len(str)+1):
        sub_str=str[i:j]
        print(sub_str,end=' ')
        list.append(sub_str)
    print()

#all sub strings are appended in the list
print(list)


















